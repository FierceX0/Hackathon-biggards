"use client";
import Navbar from "../../components/Navbar";
import ProfileCard from "../../components/ProfileCard";
import RequestCard from "../../components/RequestCard";
import AvailabilityToggle from "../../components/AvailabilityToggle";

export default function DashboardPage() {
  const requests = [
    {
      id: 1,
      hospital: "City General Hospital",
      bloodType: "A+",
      urgent: true,
      location: "Downtown Medical Center",
      date: "Monday, November 4, 2024",
    },
    {
      id: 2,
      hospital: "St. Mary's Medical Center",
      bloodType: "A+",
      urgent: false,
      location: "Westside Campus",
      date: "Tuesday, November 5, 2024",
    },
  ];

  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-50 to-blue-100">
      <Navbar />
      <div className="max-w-6xl mx-auto p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <ProfileCard />
          <AvailabilityToggle />
        </div>

        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-lg font-semibold mb-4 text-gray-800">
            Active Blood Requests
          </h2>
          <p className="text-sm text-gray-500 mb-4">
            Hospitals requesting A+ blood donors
          </p>
          <div className="space-y-4">
            {requests.map((req) => (
              <RequestCard key={req.id} {...req} />
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
