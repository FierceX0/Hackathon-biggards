"use client";

import { useState } from "react";
import InputField from "../components/InputField";
import Button from "../components/Button";

export default function LoginPage() {
  const [role, setRole] = useState("donor");

  const handleLogin = () => {
    window.location.href = "/dashboard";
  };

  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-blue-50 to-blue-100">
      <div className="text-center mb-8">
        <img src="/logo.svg" alt="Logo" className="w-12 mx-auto" />
        <h1 className="text-2xl font-semibold text-blue-800 mt-2">
          NSS BLOODLINE CONNECT
        </h1>
        <p className="text-gray-600">Real-Time Blood Donor Management</p>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-md w-[380px]">
        <h2 className="text-xl font-semibold text-center mb-6">Welcome Back</h2>

        <div className="flex bg-gray-100 rounded-full p-1 mb-6">
          <button
            onClick={() => setRole("donor")}
            className={`w-1/2 py-2 rounded-full ${
              role === "donor"
                ? "bg-white shadow font-semibold"
                : "text-gray-500"
            }`}
          >
            Donor
          </button>
          <button
            onClick={() => setRole("admin")}
            className={`w-1/2 py-2 rounded-full ${
              role === "admin"
                ? "bg-white shadow font-semibold"
                : "text-gray-500"
            }`}
          >
            Hospital Admin
          </button>
        </div>

        <InputField label="Email" type="email" placeholder="donor@example.com" />
        <InputField label="Password" type="password" placeholder="********" />

        <Button
          label={`Sign in as ${role === "donor" ? "Donor" : "Admin"}`}
          onClick={handleLogin}
          className="w-full mt-4"
        />

        <p className="text-center text-sm text-gray-400 mt-4">
          Demo: Click “Sign In” to continue
        </p>
      </div>
    </main>
  );
}
