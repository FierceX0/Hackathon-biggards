"use client";
import { useState } from "react";

export default function AvailabilityToggle() {
  const [available, setAvailable] = useState(true);

  return (
    <div className="bg-white rounded-xl shadow p-6">
      <h3 className="text-gray-800 font-semibold mb-3">Availability Status</h3>
      <p className="text-sm text-gray-600 mb-4">
        Let hospitals know if you're available to donate
      </p>
      <div className="flex items-center justify-between">
        <span className="font-medium">
          {available ? "Available" : "Not Available"}
        </span>
        <button
          onClick={() => setAvailable(!available)}
          className={`w-12 h-6 rounded-full relative transition ${
            available ? "bg-green-500" : "bg-gray-400"
          }`}
        >
          <span
            className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition ${
              available ? "translate-x-6" : ""
            }`}
          ></span>
        </button>
      </div>
    </div>
  );
}
