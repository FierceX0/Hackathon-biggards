export default function Navbar() {
  return (
    <nav className="bg-white shadow-sm py-3 px-6 flex justify-between items-center">
      <div className="flex items-center gap-2">
        <img src="/logo.svg" alt="Logo" className="w-6" />
        <span className="font-semibold text-blue-700">NSS BLOODLINE CONNECT</span>
      </div>
      <button className="text-gray-600 font-medium hover:text-blue-700">
        Logout
      </button>
    </nav>
  );
}
