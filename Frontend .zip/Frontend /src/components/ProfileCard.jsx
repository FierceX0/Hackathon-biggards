export default function ProfileCard() {
  return (
    <div className="bg-white rounded-xl shadow p-6 mb-6">
      <div className="flex flex-col items-center text-center">
        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-3">
          <span className="text-2xl text-blue-600 font-bold">🩸</span>
        </div>
        <h3 className="text-lg font-semibold">John Smith</h3>
        <p className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm mt-1">
          Blood Type: A+
        </p>
        <div className="mt-4 text-sm text-gray-600 space-y-1">
          <p>📍 Downtown</p>
          <p>📞 +1-555-0101</p>
          <p>🩸 12 donations</p>
        </div>
      </div>
    </div>
  );
}
