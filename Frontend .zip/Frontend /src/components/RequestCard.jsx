import Button from "./Button";

export default function RequestCard({ hospital, bloodType, urgent, location, date }) {
  return (
    <div className="border rounded-lg p-4 flex justify-between items-center">
      <div>
        <h4 className="font-semibold">{hospital}</h4>
        <div className="flex gap-2 text-sm mb-2">
          <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded">{bloodType}</span>
          {urgent && (
            <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded">Urgent</span>
          )}
        </div>
        <p className="text-sm text-gray-500">{location}</p>
        <p className="text-sm text-gray-500">{date}</p>
      </div>
      <div className="flex gap-2">
        <Button label="Accept Request" />
        <Button label="More Details" className="bg-white border text-gray-700" />
      </div>
    </div>
  );
}
